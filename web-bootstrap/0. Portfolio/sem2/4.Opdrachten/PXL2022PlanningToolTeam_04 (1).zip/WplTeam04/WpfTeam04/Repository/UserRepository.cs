﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfTeam04.Repository
{
    public static class UserRepository
    {
        public static Dictionary<string, UserRecord> Users = new Dictionary<string, UserRecord>();
    }
}
