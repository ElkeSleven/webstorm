﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibTeam04.Entities
{
    public class BevestigingsEmail
    {
        public string Email { get; set; }
        public int BestellingsNr { get; set; }
        public string Naam { get; set; }
        public string Voornaam { get; set; }
        public string  Adres { get; set; }
        public string KaartNummer { get; set; }
        //thank you for your order name bestellingnr

    }
}
