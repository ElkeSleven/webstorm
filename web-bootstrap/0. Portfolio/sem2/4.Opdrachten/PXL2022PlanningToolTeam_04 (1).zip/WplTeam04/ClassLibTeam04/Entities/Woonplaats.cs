﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibTeam04.Entities
{
    internal class Woonplaats
    {
        public string Postcode { get; set; }    // PK
        public string Gemeente { get; set; }   

    }
}
