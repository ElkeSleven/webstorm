﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibTeam04.Entities
{
    public class MailSender
    {
        public string Sender_voornaam { get; set; }
        public string Sender_achternaam { get; set; }
        public string Sender_email { get; set; }
        public string Sender_gsm { get; set; }
        public string Sender_klantNR { get; set; }
        public string Sender_bericht { get; set; }
    }
}
