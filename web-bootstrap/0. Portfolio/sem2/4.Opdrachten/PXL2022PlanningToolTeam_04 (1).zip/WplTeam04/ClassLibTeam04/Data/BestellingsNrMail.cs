﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibTeam04.Business
{
    public class BestellingsNrMail
    {
        public string Email { get; set; }
        public int BestellingsNr { get; set; }
        
    }
}
